# V3.1 实验归档

从 [V3.1 实验首页](exp/v3/README.md) 查找候选池、阶段报告、日志、方案和逐题结果。从 [实验过程与复现](exp/v3/RUNBOOK.md) 开始离线复算。

归档包含 P0 至 P4 的 V3.1 材料、Kaggle 预检及已复用的 V2 文件。V2 的正式实验报告及完整材料见 [V2 实验索引](https://github.com/yancyanq/fuzzy-nli-adaptive-retrieval/blob/main/INDEX.md)。

在解压后的目录运行 shasum -a 256 -c SHA256SUMS.txt。GPU 服务、模型下载和数据集分片的准备方法见 P0／P1 说明。
