# V2 实验完整材料包

*A Fuzzy-NLI-based QA Chatbot System with Adaptive Retrieval*  
BNBU NLP 课程小组实验 · 2026-11-16

本公开版供小组交接、撰写论文和从归档复算。实验日志展示版隐藏日期、时刻及时区，各 Word 原件附有同名 Markdown 对照。解压后请在本目录查看以下入口，文件路径以本目录为起点。

## 从哪里开始

| 目的 | 文件 |
|---|---|
| 从头理解每一步和决策理由 | [24 页实验过程手册 Markdown](step6_v2/NLP_V2_Experiment_Process_Handbook.md) · [Word](step6_v2/NLP_V2_Experiment_Process_Handbook.docx) |
| 查阅正式数字与图表 | [第 11 节结果册 Markdown](step6_v2/NLP_V2_Section11_Results_Booklet.md) · [Word](step6_v2/NLP_V2_Section11_Results_Booklet.docx) · [正式实验报告](step6_v2/Experiment_Report.md) · [质量与成本原图](step6_v2/quality_cost.pdf) |
| 查看实验结论及论文可用内容 | [中英文结论册 Markdown](step6_v2/NLP_V2_Experiment_Conclusions.md) · [Word](step6_v2/NLP_V2_Experiment_Conclusions.docx) · [IEEE 方法与实验章节预览](step6_v2/Methodology_and_Experimental_Results.pdf) · [LaTeX 入口](step6_v2/Methodology_and_Experimental_Results.tex) |
| 查原始方案和当时的决定 | [V2 PDF](Experiment_Protocol_v2.pdf) · [V2 Word Markdown](Experiment_Protocol_v2.md) · [Word](Experiment_Protocol_v2.docx) · [填入第 11 节结果的方案副本 Markdown](step6_v2/Experiment_Protocol_v2_Section11_Filled.md) · [Word](step6_v2/Experiment_Protocol_v2_Section11_Filled.docx) · [实验日志展示版](exp/EXPERIMENT_LOG.md) |
| 查证据和人工复核 | [错误分析记录](step6_v2/Error_Analysis.md) · [22 道案例缓存](step6_v2/error_audit_cases.json) · [空白复核表](outputs/nlp-v2-case-review/V2%20代表案例人工复核表.xlsx) · [已填写复核表](副本V2%20代表案例人工复核表.xlsx) |

参数实值和取舍见[实验关键参数与选择依据](step6_v2/NLP_V2_Experiment_Parameters.md)。

## 数据与运行材料如何放置

| 位置 | 内容 |
|---|---|
| 根目录的 `pilot.json`、`tune.json`、`test.json` | 固定的 100、500、1,000 道 bridge 题。三份清单互不重叠 |
| 根目录的 `branches.jsonl` 与 `per_question.csv` | 真实 DeepSeek 100 题预实验的分支与逐题结果 |
| `NLP_Experiment_Materials_2026-11-15/` | 保留原结构的早期材料，包括 BM25 对照、预实验人工审核、mock 源码和测试。正式测试依赖此处的 mock 路径 |
| `pilot_signals_v2/` 与 `step6a_check/` | 确认追加的桥接对照，以及本地 vLLM 的非退化接口检查，两者都包含逐题依据 |
| `step4_dev/` | 校准的 A/B 答案、NLI、门控锁、dev 逐题选择、GPU 配置和校验清单 |
| `step5_v2/` | 正式 A/B/Full 答案和句级证据、NLI 原始及修复副本、九组官方预测、逐题质量、192 条真实路径测量和运行日志 |
| `step6_v2/` | 配对区间、统计和错误分析、复现记录、结果册、结论册、过程手册和论文材料 |
| `history/` | 三份原有 ZIP 快照。使用本包其他目录取得当前资料，历史文件用于追溯 |

根目录的脚本、测试和各步 README 保持原运行布局。早期实验说明和 GPU 的真实运行命令在各阶段 README，随包所含材料及历史缺口详见 [归档范围](ARCHIVE_SCOPE.md)。数据署名及评分器许可见[数据来源](DATA_SOURCES.md)。

## 检查压缩包并复算

1. 在解压出的本目录运行以下命令，核对整包与三个阶段清单。

   ```bash
   shasum -a 256 -c SHA256SUMS.txt
   shasum -a 256 -c step6_v2/reproducibility.sha256
   (cd step4_dev && shasum -a 256 -c results.sha256)
   shasum -a 256 -c step5_v2/archive.sha256
   ```

2. 使用 Python 3.10 或以上的独立环境。离线统计需要 `rank-bm25`、`numpy`、`reportlab`。正式阶段合成测试另需 `openai` 和 `httpx`，版本建议与[复现清单](step6_v2/Reproducibility_Checklist.md)一致。直接运行下列测试只使用合成数据和内存 mock。

   ```bash
   python3 -m unittest discover -s . -p 'test_*.py'
   ```

3. 按[复现清单](step6_v2/Reproducibility_Checklist.md)或[过程手册 Markdown](step6_v2/NLP_V2_Experiment_Process_Handbook.md) · [Word](step6_v2/NLP_V2_Experiment_Process_Handbook.docx)附录，在临时目录依序复算门控锁定、正式评分和配对分析，并与归档比较。[步骤 4](README_step4_v2.md)、[步骤 5](README_step5_v2.md)、[步骤 6](README_step6_v2.md)各有详细说明。

`step5_v2/inputs.sha256` 保留了服务器 `~/nlp` 的部署路径。检查解压包时使用上面的根目录清单。带 `mock` 的历史输出和合成题属于流程测试，真实运行以正式目录、预实验导出和实验日志为准。
